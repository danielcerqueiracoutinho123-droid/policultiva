import React, { useState, useRef, useEffect } from 'react';

const THRESHOLD = 70;

export default function PullToRefresh({ onRefresh, children }) {
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const startY = useRef(null);
  const pullRef = useRef(0);
  const refreshingRef = useRef(false);

  useEffect(() => {
    const onTouchStart = (e) => {
      if (window.scrollY <= 0 && !refreshingRef.current) {
        startY.current = e.touches[0].clientY;
      } else {
        startY.current = null;
      }
    };
    const onTouchMove = (e) => {
      if (startY.current === null || refreshingRef.current) return;
      const delta = e.touches[0].clientY - startY.current;
      if (delta > 0 && window.scrollY <= 0) {
        const p = Math.min(delta * 0.5, 100);
        pullRef.current = p;
        setPull(p);
      }
    };
    const onTouchEnd = async () => {
      if (pullRef.current >= THRESHOLD && !refreshingRef.current) {
        refreshingRef.current = true;
        setRefreshing(true);
        setPull(THRESHOLD);
        try {
          await onRefresh();
        } finally {
          refreshingRef.current = false;
          setRefreshing(false);
          pullRef.current = 0;
          setPull(0);
          startY.current = null;
        }
      } else {
        pullRef.current = 0;
        setPull(0);
        startY.current = null;
      }
    };
    window.addEventListener('touchstart', onTouchStart, { passive: true });
    window.addEventListener('touchmove', onTouchMove, { passive: true });
    window.addEventListener('touchend', onTouchEnd);
    return () => {
      window.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
    };
  }, [onRefresh]);

  return (
    <>
      <div className="flex items-center justify-center overflow-hidden transition-[height] duration-150" style={{ height: pull }}>
        <div
          className={`w-7 h-7 border-4 border-muted border-t-primary rounded-full ${refreshing ? 'animate-spin' : ''}`}
          style={{ opacity: Math.min(pull / THRESHOLD, 1) }}
        />
      </div>
      {children}
    </>
  );
}
