import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Wifi, Info } from 'lucide-react';
import DeviceCard from './DeviceCard';
import DeviceDialog from './DeviceDialog';

export default function WiFiPanel({ devices, fields, onAdd, onReading, onToggle, onDelete }) {
  const [addOpen, setAddOpen] = useState(false);
  const fieldOf = (d) => fields.find((f) => f.id === d.field_id);

  return (
    <div className="space-y-4">
      <Card className="border-sky-300 bg-sky-50 dark:border-sky-800 dark:bg-sky-950/40">
        <CardContent className="p-3 flex items-start gap-2 text-sm text-sky-800 dark:text-sky-200">
          <Info className="w-4 h-4 shrink-0 mt-0.5" />
          <div className="space-y-1.5">
            <p>Conecte placas <strong>ESP32</strong> na sua rede Wi-Fi e cadastre o IP local de cada uma.</p>
            <p>O firmware do ESP32 deve expor: <code className="bg-sky-100 dark:bg-sky-900/60 px-1 rounded">GET /status</code> (retorna <em>moisture</em>, <em>battery</em> e <em>relay</em>) e <code className="bg-sky-100 dark:bg-sky-900/60 px-1 rounded">POST /relay</code> (liga/desliga o relé).</p>
            <p>Use o app nativo ou acesse pela rede local em HTTP — navegadores bloqueiam requisições HTTP a partir de páginas HTTPS.</p>
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Wifi className="w-5 h-5 text-sky-600" />
          <span className="font-medium">Dispositivos do Solo</span>
          <span className="text-sm text-muted-foreground">({devices.length})</span>
        </div>
        <Button size="sm" onClick={() => setAddOpen(true)}><Plus className="w-4 h-4 mr-1" /> Conectar dispositivos</Button>
      </div>

      {devices.length === 0 ? (
        <Card><CardContent className="p-8 text-center text-muted-foreground">
          <Wifi className="w-10 h-10 mx-auto mb-3 opacity-40" />
          Nenhum dispositivo registrado. Adicione sensores de umidade, regadores e drenadores para conectar via Wi-Fi.
        </CardContent></Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {devices.map((d) => (
            <DeviceCard
              key={d.id}
              device={d}
              field={fieldOf(d)}
              onReading={onReading}
              onToggle={onToggle}
              onDelete={onDelete}
            />
          ))}
        </div>
      )}

      <DeviceDialog open={addOpen} onOpenChange={setAddOpen} onSave={onAdd} fields={fields} />
    </div>
  );
}
