import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Sprout, Droplets, Wallet, Layers, AlertTriangle, Plus, MapPin } from 'lucide-react';
import { humidityStatus, SOIL_LABELS } from '@/lib/irrigation';

export default function OverviewPanel({ fields, crops, transactions, onAddField, onAddCrop }) {
  const totalArea = fields.reduce((s, f) => s + (Number(f.area_hectares) || 0), 0);
  const totalWater = fields.reduce((s, f) => s + (Number(f.water_available_liters) || 0), 0);
  const alerts = crops.filter((c) => humidityStatus(c) !== 'ideal').length;
  const receitas = transactions.filter((t) => t.type === 'receita').reduce((s, t) => s + (Number(t.amount) || 0), 0);
  const despesas = transactions.filter((t) => t.type === 'despesa').reduce((s, t) => s + (Number(t.amount) || 0), 0);
  const saldo = receitas - despesas;

  const stats = [
    { label: 'Área total', value: `${totalArea.toFixed(1)} ha`, icon: Layers, color: 'text-emerald-600', bg: 'bg-emerald-100' },
    { label: 'Água disponível', value: `${(totalWater / 1000).toFixed(1)}k L`, icon: Droplets, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Culturas ativas', value: crops.length, icon: Sprout, color: 'text-primary', bg: 'bg-primary/10' },
    { label: 'Alertas de umidade', value: alerts, icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-100' },
    { label: 'Saldo financeiro', value: `R$ ${saldo.toFixed(2)}`, icon: Wallet, color: saldo >= 0 ? 'text-emerald-600' : 'text-destructive', bg: saldo >= 0 ? 'bg-emerald-100' : 'bg-red-100' },
  ];

  return (
    <div className="space-y-6">
      <Card className="bg-primary/5 border-primary/20 shadow-soft">
        <CardContent className="p-4">
          <h2 className="font-semibold mb-3">Como usar (passo a passo)</h2>
          <div className="grid gap-3 sm:grid-cols-4">
            {[
              { n: 1, t: 'Criar talhão', d: 'Dê o nome e a área da sua terra.' },
              { n: 2, t: 'Plantar culturas', d: 'Adicione o que vai plantar em cada talhão.' },
              { n: 3, t: 'Cuidar da água', d: 'Veja a umidade e resolva se estiver seco ou molhado.' },
              { n: 4, t: 'Anotar dinheiro', d: 'Registre vendas e gastos no Financeiro.' },
            ].map((s) => (
              <div key={s.n} className="flex gap-3">
                <div className="w-7 h-7 shrink-0 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">{s.n}</div>
                <div>
                  <p className="font-medium text-sm">{s.t}</p>
                  <p className="text-sm text-muted-foreground">{s.d}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-3 grid-cols-2 lg:grid-cols-5">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <Card key={s.label} className="shadow-soft">
              <CardContent className="p-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${s.bg}`}>
                  <Icon className={`w-5 h-5 ${s.color}`} />
                </div>
                <p className="text-sm text-muted-foreground">{s.label}</p>
                <p className="text-lg font-bold">{s.value}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-lg font-semibold">Talhões e culturas</h2>
        <div className="flex gap-2">
          <Button size="lg" variant="outline" onClick={onAddCrop}><Plus className="w-5 h-5 mr-2" /> Cultura</Button>
          <Button size="lg" onClick={onAddField}><Plus className="w-5 h-5 mr-2" /> Talhão</Button>
        </div>
      </div>

      {fields.length === 0 ? (
        <Card><CardContent className="p-8 text-center text-muted-foreground">
          <MapPin className="w-10 h-10 mx-auto mb-3 opacity-40" />
          Nenhum talhão cadastrado. Comece registrando a sua primeira área.
        </CardContent></Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {fields.map((f) => {
            const fCrops = crops.filter((c) => c.field_id === f.id);
            return (
              <Card key={f.id} className="shadow-soft">
                <CardContent className="p-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold">{f.name}</h3>
                    <span className="text-sm text-muted-foreground">{f.region}</span>
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
                    <span>{f.area_hectares} ha</span>
                    <span>Solo: {SOIL_LABELS[f.soil_type]}</span>
                    <span>Água: {(Number(f.water_available_liters) / 1000).toFixed(1)}k L</span>
                    <span>Irrigação: {f.irrigation_mode === 'automatico' ? 'Automática' : 'Manual'}</span>
                  </div>
                  <div className="flex flex-wrap gap-2 pt-1">
                    {fCrops.length === 0 && <span className="text-sm text-muted-foreground">Sem culturas neste talhão.</span>}
                    {fCrops.map((c) => {
                      const st = humidityStatus(c);
                      const color = st === 'ideal' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700';
                      return <span key={c.id} className={`text-sm px-2 py-0.5 rounded-full ${color}`}>{c.name} · {c.humidity}%</span>;
                    })}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}