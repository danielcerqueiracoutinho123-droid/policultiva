import React, { useState, useCallback } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Sparkles, Sprout, Scissors, Droplets, Waves, RefreshCw, Loader2, CalendarDays, Leaf } from 'lucide-react';
import { getRecommendations } from '@/lib/weather';
import { analyzeCompanions, suggestCompanions, CROP_LABELS } from '@/lib/companions';

const ACTION_META = {
  plantar: { label: 'Plantar', icon: Sprout, color: 'text-emerald-600', bg: 'bg-emerald-100' },
  cultivar: { label: 'Cultivar / Capinar', icon: Scissors, color: 'text-amber-600', bg: 'bg-amber-100' },
  regar: { label: 'Regar', icon: Droplets, color: 'text-blue-600', bg: 'bg-blue-100' },
  drenar: { label: 'Drenar água', icon: Waves, color: 'text-indigo-600', bg: 'bg-indigo-100' },
};

export default function RecommendationsPanel({ farmProfile, crops }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchRecs = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getRecommendations({ farmProfile, crops });
      setData(res);
    } catch (e) {
      setError(e?.message === 'Cidade não encontrada' ? 'Não encontrei a cidade do seu cadastro para buscar a previsão.' : 'Não consegui buscar a previsão agora. Verifique a internet e tente novamente.');
    } finally {
      setLoading(false);
    }
  }, [farmProfile, crops]);

  return (
    <div className="space-y-5">
      <Card className="bg-gradient-to-r from-emerald-600 to-green-500 text-white border-0 shadow-soft">
        <CardContent className="p-5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center ring-1 ring-white/30">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Recomendações inteligentes</h2>
              <p className="text-sm text-emerald-50/90">O melhor dia para plantar, cultivar, regar e drenar</p>
            </div>
          </div>
          <Button variant="secondary" onClick={fetchRecs} disabled={loading}>
            {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
            {data ? 'Atualizar' : 'Gerar recomendações'}
          </Button>
        </CardContent>
      </Card>

      {crops.length > 0 && (() => {
        const { good, bad } = analyzeCompanions(crops.map((c) => c.name));
        const suggestions = suggestCompanions(crops.map((c) => c.name));
        if (!good.length && !bad.length && !suggestions.length) return null;
        return (
          <Card className="border-emerald-300 bg-emerald-50 dark:border-emerald-800 dark:bg-emerald-950/40 shadow-soft">
            <CardContent className="p-5 space-y-4">
              <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400">
                <Leaf className="w-5 h-5" />
                <h3 className="font-semibold">Consórcios — o que dá certo plantar junto</h3>
              </div>
              {good.length > 0 && (
                <div className="space-y-1.5">
                  <p className="text-sm font-medium text-emerald-800 dark:text-emerald-200">✓ Combinações favoráveis nas suas culturas</p>
                  <div className="flex flex-wrap gap-2">
                    {good.map(([a, b], i) => (
                      <span key={i} className="inline-flex items-center gap-1 text-sm bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200 rounded-full px-3 py-1">
                        {CROP_LABELS[a]} + {CROP_LABELS[b]}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              {suggestions.length > 0 && (
                <div className="space-y-1.5">
                  <p className="text-sm font-medium text-emerald-800 dark:text-emerald-200">🌱 Considere plantar junto ao que você já tem</p>
                  <div className="flex flex-wrap gap-2">
                    {suggestions.map((s) => (
                      <span key={s} className="inline-flex items-center gap-1 text-sm bg-white dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-full px-3 py-1">
                        {CROP_LABELS[s]}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              {bad.length > 0 && (
                <div className="space-y-1.5">
                  <p className="text-sm font-medium text-amber-800 dark:text-amber-200">⚠ Evite plantar essas juntas</p>
                  <div className="flex flex-wrap gap-2">
                    {bad.map(([a, b], i) => (
                      <span key={i} className="inline-flex items-center gap-1 text-sm bg-amber-100 dark:bg-amber-900/40 text-amber-800 dark:text-amber-200 rounded-full px-3 py-1">
                        {CROP_LABELS[a]} + {CROP_LABELS[b]}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })()}

      {error && <p className="text-sm text-destructive text-center">{error}</p>}

      {loading && !data && (
        <Card><CardContent className="p-10 text-center text-muted-foreground">
          <Loader2 className="w-8 h-8 mx-auto mb-3 animate-spin text-primary" />
          Analisando a previsão do tempo e suas culturas...
        </CardContent></Card>
      )}

      {data && (
        <>
          {data.weather_summary && (
            <Card className="shadow-soft"><CardContent className="p-4 flex items-start gap-3">
              <CalendarDays className="w-5 h-5 text-primary mt-0.5 shrink-0" />
              <p className="text-sm text-muted-foreground">{data.weather_summary}</p>
            </CardContent></Card>
          )}
          <div className="grid gap-4 md:grid-cols-2">
            {data.recommendations?.map((r, i) => {
              const meta = ACTION_META[r.action] || ACTION_META.regar;
              const Icon = meta.icon;
              return (
                <Card key={i} className="shadow-soft">
                  <CardContent className="p-5">
                    <div className="flex items-center gap-3 mb-3">
                      <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${meta.bg}`}>
                        <Icon className={`w-6 h-6 ${meta.color}`} />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">{meta.label}</p>
                        <p className="font-bold text-base">{r.best_day}</p>
                      </div>
                    </div>
                    <p className="text-sm text-foreground/90 mb-2">{r.reason}</p>
                    {r.tips && (
                      <p className="text-sm text-muted-foreground bg-muted/50 rounded-lg p-2.5">
                        💡 {r.tips}
                      </p>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </>
      )}

      {!loading && !data && !error && (
        <Card><CardContent className="p-10 text-center text-muted-foreground">
          <Sparkles className="w-10 h-10 mx-auto mb-3 opacity-40" />
          Clique em "Gerar recomendações" para receber o melhor dia de cada atividade, baseado na previsão do tempo da sua região.
        </CardContent></Card>
      )}
    </div>
  );
}