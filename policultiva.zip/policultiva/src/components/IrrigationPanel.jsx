import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, AlertTriangle, CheckCircle2, Droplets } from 'lucide-react';
import { humidityStatus } from '@/lib/irrigation';
import CropCard from './CropCard';

export default function IrrigationPanel({ crops, fields, onResolve, onUpdateHumidity, onDelete, onAddCrop }) {
  const alerts = crops.filter((c) => humidityStatus(c) !== 'ideal');
  const fieldOf = (c) => fields.find((f) => f.id === c.field_id);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          {alerts.length > 0 ? (
            <AlertTriangle className="w-5 h-5 text-amber-500" />
          ) : (
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          )}
          <span className="font-medium">
            {alerts.length > 0
              ? `${alerts.length} cultura(s) com umidade fora da faixa ideal`
              : 'Todas as culturas com umidade ideal'}
          </span>
        </div>
        <Button size="sm" onClick={onAddCrop}><Plus className="w-4 h-4 mr-1" /> Nova cultura</Button>
      </div>

      {crops.length === 0 ? (
        <Card><CardContent className="p-8 text-center text-muted-foreground">
          <Droplets className="w-10 h-10 mx-auto mb-3 opacity-40" />
          Nenhuma cultura cadastrada. Adicione culturas aos talhões para automatizar a irrigação.
        </CardContent></Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {crops.map((c) => (
            <CropCard key={c.id} crop={c} field={fieldOf(c)} onResolve={onResolve} onUpdateHumidity={onUpdateHumidity} onDelete={onDelete} />
          ))}
        </div>
      )}
    </div>
  );
}
