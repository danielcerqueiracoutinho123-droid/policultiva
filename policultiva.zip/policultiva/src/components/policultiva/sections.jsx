import React from 'react';
import { useFarm } from '@/lib/FarmContext';
import OverviewPanel from '@/components/OverviewPanel';
import RecommendationsPanel from '@/components/RecommendationsPanel';
import IrrigationPanel from '@/components/IrrigationPanel';
import WiFiPanel from '@/components/WiFiPanel';
import FinancePanel from '@/components/FinancePanel';
import CropsPanel from '@/components/CropsPanel';

export function OverviewSection() {
  const f = useFarm();
  return (
    <OverviewPanel
      fields={f.fields} crops={f.crops} transactions={f.transactions}
      onAddField={() => f.setFieldOpen(true)} onAddCrop={() => f.setCropOpen(true)}
    />
  );
}

export function RecommendationsSection() {
  const f = useFarm();
  return <RecommendationsPanel farmProfile={f.profile} crops={f.crops} />;
}

export function IrrigationSection() {
  const f = useFarm();
  return (
    <IrrigationPanel
      crops={f.crops} fields={f.fields}
      onResolve={f.resolveCrop} onUpdateHumidity={f.updateHumidity} onDelete={f.deleteCrop}
      onAddCrop={() => f.setCropOpen(true)}
    />
  );
}

export function DevicesSection() {
  const f = useFarm();
  return (
    <WiFiPanel
      devices={f.devices} fields={f.fields}
      onAdd={f.addDevice} onReading={f.deviceReading} onToggle={f.toggleDevice} onDelete={f.deleteDevice}
    />
  );
}

export function FinanceSection() {
  const f = useFarm();
  return <FinancePanel transactions={f.transactions} crops={f.crops} onAdd={f.addTransaction} onDelete={f.deleteTransaction} />;
}

export function CropsSection() {
  const f = useFarm();
  return <CropsPanel crops={f.crops} fields={f.fields} onAddCrop={() => f.setCropOpen(true)} onDelete={f.deleteCrop} />;
}
