import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';

const TYPE_LABELS = {
  sensor: 'Sensor de Umidade',
  irrigator: 'Regador',
  drainer: 'Drenador',
};

export default function DeviceDialog({ open, onOpenChange, onSave, fields }) {
  const [name, setName] = useState('');
  const [type, setType] = useState('sensor');
  const [ipAddress, setIpAddress] = useState('');
  const [fieldId, setFieldId] = useState('');

  const submit = () => {
    if (!name.trim() || !ipAddress.trim()) return;
    onSave({ name: name.trim(), type, ip_address: ipAddress.trim(), field_id: fieldId || undefined });
    setName('');
    setType('sensor');
    setIpAddress('');
    setFieldId('');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Registrar Dispositivo</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label>Nome do dispositivo</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex: Sensor Talhão A" />
          </div>
          <div className="space-y-2">
            <Label>Tipo</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(TYPE_LABELS).map(([v, l]) => (
                  <SelectItem key={v} value={v}>{l}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>IP do ESP32 (rede local)</Label>
            <Input value={ipAddress} onChange={(e) => setIpAddress(e.target.value)} placeholder="Ex: 192.168.1.50" />
          </div>
          {fields.length > 0 && (
            <div className="space-y-2">
              <Label>Talhão (opcional)</Label>
              <Select value={fieldId} onValueChange={setFieldId}>
                <SelectTrigger><SelectValue placeholder="Sem talhão" /></SelectTrigger>
                <SelectContent>
                  {fields.map((f) => (
                    <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button onClick={submit} disabled={!name.trim() || !ipAddress.trim()}>Registrar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
