import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Droplets, Gauge, Battery, Wifi, Power, Trash2, Radio } from 'lucide-react';
import { getStatus, setOutputState } from '@/lib/wifi';

const TYPE_META = {
  sensor: { icon: Gauge, color: 'text-blue-600', label: 'Sensor de Umidade' },
  irrigator: { icon: Droplets, color: 'text-sky-600', label: 'Regador' },
  drainer: { icon: Radio, color: 'text-amber-600', label: 'Drenador' },
};

export default function DeviceCard({ device, field, onReading, onToggle, onDelete }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const meta = TYPE_META[device.type] || TYPE_META.sensor;
  const Icon = meta.icon;

  const handleConnect = async () => {
    setError(null);
    setBusy(true);
    try {
      const status = await getStatus(device.ip_address);
      const updates = { connected: true };
      if (device.type === 'sensor' && status.moisture != null) updates.moisture = status.moisture;
      if (status.battery != null) updates.battery = status.battery;
      if (device.type !== 'sensor' && status.relay != null) updates.is_on = !!status.relay;
      await onReading(device, updates);
    } catch (e) {
      setError(e.message || 'Falha ao conectar ao ESP32');
    } finally {
      setBusy(false);
    }
  };

  const handleDisconnect = async () => {
    await onReading(device, { connected: false });
  };

  const handleToggle = async () => {
    setError(null);
    setBusy(true);
    try {
      await setOutputState(device.ip_address, !device.is_on);
      await onToggle(device, !device.is_on);
    } catch (e) {
      setError(e.message || 'Falha no comando');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card className={device.connected ? 'ring-2 ring-sky-400' : ''}>
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center">
              <Icon className={`w-5 h-5 ${meta.color}`} />
            </div>
            <div>
              <p className="font-semibold leading-tight">{device.name}</p>
              <p className="text-sm text-muted-foreground">{meta.label}{field ? ` · ${field.name}` : ''}</p>
              <p className="text-sm text-muted-foreground/70">{device.ip_address}</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="h-11 w-11" aria-label="Remover dispositivo" onClick={() => onDelete(device)}>
            <Trash2 className="w-5 h-5 text-muted-foreground" />
          </Button>
        </div>

        {device.connected ? (
          <div className="flex items-center gap-1.5 text-sm font-medium text-sky-600">
            <Wifi className="w-3.5 h-3.5" /> Conectado
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
            <Wifi className="w-3.5 h-3.5" /> Desconectado
          </div>
        )}

        {device.type === 'sensor' && device.moisture != null && (
          <div className="space-y-1">
            <div className="flex items-center justify-between text-sm">
              <span className="flex items-center gap-1 text-muted-foreground"><Droplets className="w-3 h-3" /> Umidade</span>
              <span className="font-medium">{device.moisture}%</span>
            </div>
            <Progress value={device.moisture} className="h-2" />
          </div>
        )}

        {device.battery != null && (
          <div className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-1 text-muted-foreground"><Battery className="w-3 h-3" /> Bateria</span>
            <span className="font-medium">{device.battery}%</span>
          </div>
        )}

        {device.type !== 'sensor' && (
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Estado</span>
            <span className={`font-medium ${device.is_on ? 'text-emerald-600' : 'text-muted-foreground'}`}>
              {device.is_on ? 'Ligado' : 'Desligado'}
            </span>
          </div>
        )}

        {error && <p className="text-sm text-red-500">{error}</p>}

        <div className="flex gap-2 pt-1">
          {device.connected ? (
            <Button size="sm" variant="outline" onClick={handleDisconnect} disabled={busy} className="flex-1">
              <Wifi className="w-4 h-4 mr-1" /> Desconectar
            </Button>
          ) : (
            <Button size="sm" onClick={handleConnect} disabled={busy} className="flex-1">
              <Wifi className="w-4 h-4 mr-1" />
              {busy ? 'Conectando…' : 'Conectar'}
            </Button>
          )}
          {device.type !== 'sensor' && (
            <Button
              size="sm"
              variant={device.is_on ? 'destructive' : 'default'}
              onClick={handleToggle}
              disabled={busy || !device.connected}
              className="flex-1"
            >
              <Power className="w-4 h-4 mr-1" />
              {device.is_on ? 'Desligar' : 'Ligar'}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}