import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Trash2, TrendingUp, TrendingDown, Wallet } from 'lucide-react';

const today = () => new Date().toISOString().slice(0, 10);

export default function FinancePanel({ transactions, crops, onAdd, onDelete }) {
  const [form, setForm] = useState({ description: '', type: 'despesa', category: '', amount: '', date: today(), crop_id: '' });

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const submit = (e) => {
    e.preventDefault();
    if (!form.description || !form.amount) return;
    onAdd({ ...form, amount: Number(form.amount), crop_id: form.crop_id || undefined });
    setForm({ description: '', type: 'despesa', category: '', amount: '', date: today(), crop_id: '' });
  };

  const receitas = transactions.filter((t) => t.type === 'receita').reduce((s, t) => s + (Number(t.amount) || 0), 0);
  const despesas = transactions.filter((t) => t.type === 'despesa').reduce((s, t) => s + (Number(t.amount) || 0), 0);
  const saldo = receitas - despesas;
  const cropName = (id) => crops.find((c) => c.id === id)?.name;

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <div className="space-y-4 lg:col-span-1">
        <div className="grid grid-cols-3 gap-3">
          <Card><CardContent className="p-3">
            <TrendingUp className="w-4 h-4 text-emerald-600 mb-1" />
            <p className="text-sm text-muted-foreground">Receitas</p>
            <p className="font-semibold text-emerald-600">R$ {receitas.toFixed(2)}</p>
          </CardContent></Card>
          <Card><CardContent className="p-3">
            <TrendingDown className="w-4 h-4 text-destructive mb-1" />
            <p className="text-sm text-muted-foreground">Despesas</p>
            <p className="font-semibold text-destructive">R$ {despesas.toFixed(2)}</p>
          </CardContent></Card>
          <Card><CardContent className="p-3">
            <Wallet className="w-4 h-4 text-primary mb-1" />
            <p className="text-sm text-muted-foreground">Saldo</p>
            <p className={`font-semibold ${saldo >= 0 ? 'text-emerald-600' : 'text-destructive'}`}>R$ {saldo.toFixed(2)}</p>
          </CardContent></Card>
        </div>

        <Card><CardContent className="p-4">
          <h3 className="font-semibold mb-3">Registrar movimentação</h3>
          <form onSubmit={submit} className="space-y-3">
            <div>
              <Label>Descrição</Label>
              <Input value={form.description} onChange={(e) => set('description', e.target.value)} placeholder="Ex: Venda de tomate" required />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Tipo</Label>
                <Select value={form.type} onValueChange={(v) => set('type', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="receita">Receita</SelectItem>
                    <SelectItem value="despesa">Despesa</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Valor (R$)</Label>
                <Input type="number" step="0.01" min="0" value={form.amount} onChange={(e) => set('amount', e.target.value)} required />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Categoria</Label>
                <Input value={form.category} onChange={(e) => set('category', e.target.value)} placeholder="Ex: Sementes" />
              </div>
              <div>
                <Label>Data</Label>
                <Input type="date" value={form.date} onChange={(e) => set('date', e.target.value)} required />
              </div>
            </div>
            <div>
              <Label>Cultura (opcional)</Label>
              <Select value={form.crop_id} onValueChange={(v) => set('crop_id', v)}>
                <SelectTrigger><SelectValue placeholder="Nenhuma" /></SelectTrigger>
                <SelectContent>
                  {crops.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <Button type="submit" className="w-full">Adicionar</Button>
          </form>
        </CardContent></Card>
      </div>

      <Card className="lg:col-span-2"><CardContent className="p-4">
        <h3 className="font-semibold mb-3">Extrato</h3>
        {transactions.length === 0 ? (
          <p className="text-sm text-muted-foreground py-6 text-center">Nenhuma movimentação registrada.</p>
        ) : (
          <ul className="divide-y">
            {transactions.map((t) => (
              <li key={t.id} className="flex items-center justify-between py-2">
                <div>
                  <p className="text-sm font-medium">{t.description}</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(t.date).toLocaleDateString('pt-BR')} · {t.category || '—'} {cropName(t.crop_id) ? `· ${cropName(t.crop_id)}` : ''}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`font-semibold ${t.type === 'receita' ? 'text-emerald-600' : 'text-destructive'}`}>
                    {t.type === 'receita' ? '+' : '-'} R$ {Number(t.amount).toFixed(2)}
                  </span>
                  <button onClick={() => onDelete(t.id)} aria-label="Remover movimentação" className="p-2 -mr-2 text-muted-foreground hover:text-destructive"><Trash2 className="w-5 h-5" /></button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent></Card>
    </div>
  );
}