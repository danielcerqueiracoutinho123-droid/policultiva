import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';

const empty = { field_id: '', name: '', variety: '', planted_area_hectares: '', min_humidity: '', max_humidity: '', humidity: '', planted_date: '', expected_harvest_date: '' };

export default function CropDialog({ open, onOpenChange, onSave, fields }) {
  const [form, setForm] = useState(empty);
  useEffect(() => { if (open) setForm({ ...empty, field_id: fields[0]?.id || '' }); }, [open, fields]);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = (e) => {
    e.preventDefault();
    onSave({
      ...form,
      planted_area_hectares: Number(form.planted_area_hectares),
      min_humidity: Number(form.min_humidity),
      max_humidity: Number(form.max_humidity),
      humidity: Number(form.humidity),
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>Nova cultura</DialogTitle></DialogHeader>
        {fields.length === 0 ? (
          <p className="text-sm text-muted-foreground">Cadastre um talhão antes de adicionar culturas.</p>
        ) : (
          <form onSubmit={submit} className="space-y-3">
            <div>
              <Label>Talhão</Label>
              <Select value={form.field_id} onValueChange={(v) => set('field_id', v)}>
                <SelectTrigger><SelectValue placeholder="Selecione o talhão" /></SelectTrigger>
                <SelectContent>
                  {fields.map((f) => <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Cultura</Label><Input value={form.name} onChange={(e) => set('name', e.target.value)} placeholder="Ex: Milho" required /></div>
              <div><Label>Variedade</Label><Input value={form.variety} onChange={(e) => set('variety', e.target.value)} placeholder="Ex: Hibrido X" /></div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div><Label>Área (ha)</Label><Input type="number" step="0.01" min="0" value={form.planted_area_hectares} onChange={(e) => set('planted_area_hectares', e.target.value)} required /></div>
              <div><Label>Umidade mín %</Label><Input type="number" min="0" max="100" value={form.min_humidity} onChange={(e) => set('min_humidity', e.target.value)} required /></div>
              <div><Label>Umidade máx %</Label><Input type="number" min="0" max="100" value={form.max_humidity} onChange={(e) => set('max_humidity', e.target.value)} required /></div>
            </div>
            <div><Label>Umidade atual do solo (%)</Label><Input type="number" min="0" max="100" value={form.humidity} onChange={(e) => set('humidity', e.target.value)} required /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Plantio</Label><Input type="date" value={form.planted_date} onChange={(e) => set('planted_date', e.target.value)} /></div>
              <div><Label>Colheita prevista</Label><Input type="date" value={form.expected_harvest_date} onChange={(e) => set('expected_harvest_date', e.target.value)} /></div>
            </div>
            <DialogFooter><Button type="submit">Salvar cultura</Button></DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
