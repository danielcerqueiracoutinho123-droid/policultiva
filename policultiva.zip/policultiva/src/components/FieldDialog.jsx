import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { SOIL_LABELS, SOIL_WATER_NOTES } from '@/lib/irrigation';

const empty = { name: '', area_hectares: '', region: '', soil_type: 'franco', water_source: '', water_available_liters: '', irrigation_mode: 'automatico' };

export default function FieldDialog({ open, onOpenChange, onSave }) {
  const [form, setForm] = useState(empty);
  useEffect(() => { if (open) setForm(empty); }, [open]);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = (e) => {
    e.preventDefault();
    onSave({
      ...form,
      area_hectares: Number(form.area_hectares),
      water_available_liters: Number(form.water_available_liters),
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>Novo talhão</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div><Label>Nome do talhão</Label><Input value={form.name} onChange={(e) => set('name', e.target.value)} placeholder="Ex: Sítio Norte" required /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Área (ha)</Label><Input type="number" step="0.01" min="0" value={form.area_hectares} onChange={(e) => set('area_hectares', e.target.value)} required /></div>
            <div><Label>Região</Label><Input value={form.region} onChange={(e) => set('region', e.target.value)} placeholder="Ex: Cerrado" required /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Tipo de solo</Label>
              <Select value={form.soil_type} onValueChange={(v) => set('soil_type', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(SOIL_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Irrigação</Label>
              <Select value={form.irrigation_mode} onValueChange={(v) => set('irrigation_mode', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="automatico">Automática</SelectItem>
                  <SelectItem value="manual">Manual</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div><Label>Fonte de água</Label><Input value={form.water_source} onChange={(e) => set('water_source', e.target.value)} placeholder="Ex: Poço artesiano" required /></div>
          <div><Label>Água disponível (litros)</Label><Input type="number" min="0" value={form.water_available_liters} onChange={(e) => set('water_available_liters', e.target.value)} required /></div>
          <p className="text-sm text-muted-foreground">{SOIL_WATER_NOTES[form.soil_type]}</p>
          <DialogFooter><Button type="submit">Salvar talhão</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
