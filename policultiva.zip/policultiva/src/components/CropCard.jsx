import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Sprout, AlertTriangle, CheckCircle2, Droplets, Trash2 } from 'lucide-react';
import { humidityStatus, targetHumidity } from '@/lib/irrigation';

const BAR_COLOR = {
  baixa: 'bg-amber-500',
  alta: 'bg-blue-500',
  ideal: 'bg-emerald-500',
};
const STATUS = {
  baixa: { label: 'Umidade baixa', badge: 'text-amber-700 bg-amber-100', icon: AlertTriangle, action: 'Irrigar agora' },
  alta: { label: 'Umidade alta', badge: 'text-blue-700 bg-blue-100', icon: Droplets, action: 'Drenar agora' },
  ideal: { label: 'Tudo certo', badge: 'text-emerald-700 bg-emerald-100', icon: CheckCircle2, action: null },
};

export default function CropCard({ crop, field, onResolve, onUpdateHumidity, onDelete }) {
  const [localH, setLocalH] = useState(Number(crop.humidity ?? 0));
  useEffect(() => { setLocalH(Number(crop.humidity ?? 0)); }, [crop.humidity]);

  const live = { ...crop, humidity: localH };
  const status = humidityStatus(live);
  const s = STATUS[status];
  const Icon = s.icon;
  const target = targetHumidity(crop);
  const pct = Math.min(100, Math.max(0, localH));
  const auto = field?.irrigation_mode === 'automatico';

  const commit = () => {
    if (localH !== Number(crop.humidity ?? 0)) onUpdateHumidity(crop, localH);
  };

  return (
    <Card className="overflow-hidden">
      <div className={`h-1.5 ${BAR_COLOR[status]}`} />
      <CardContent className="p-4 space-y-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center">
              <Sprout className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-bold leading-tight">{crop.name}</h3>
              <p className="text-sm text-muted-foreground">{crop.variety || 'Sem variedade'}</p>
            </div>
          </div>
          <Badge className={s.badge}><Icon className="w-3 h-3 mr-1" />{s.label}</Badge>
        </div>

        <div className="flex items-end justify-between">
          <div>
            <p className="text-sm text-muted-foreground">Umidade do solo</p>
            <p className="text-3xl font-bold leading-none">{localH}<span className="text-base font-medium">%</span></p>
          </div>
          <div className="text-right text-sm text-muted-foreground">
            <p>Ideal: {crop.min_humidity}% a {crop.max_humidity}%</p>
            <p>Alvo: {target}%</p>
          </div>
        </div>

        <div className="h-3 rounded-full bg-muted overflow-hidden">
          <div className={`h-full rounded-full ${BAR_COLOR[status]}`} style={{ width: `${pct}%` }} />
        </div>

        <div className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground">Medir:</span>
          <input
            type="range" min={0} max={100}
            value={localH}
            onChange={(e) => setLocalH(Number(e.target.value))}
            onPointerUp={commit}
            onKeyUp={commit}
            className="flex-1 accent-primary"
            aria-label="Medir umidade do solo"
          />
        </div>

        {status !== 'ideal' && (
          <div className="flex items-center justify-between gap-2 rounded-lg bg-muted px-3 py-2">
            <span className="text-sm text-muted-foreground">{auto ? 'Modo automático' : s.action}</span>
            <button
              onClick={() => onResolve(crop)}
              className="inline-flex items-center gap-2 rounded-lg bg-primary text-primary-foreground px-4 py-2 text-sm font-semibold hover:opacity-90"
            >
              {status === 'baixa' ? <Droplets className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
              Resolver
            </button>
          </div>
        )}

        <div className="flex items-center justify-between text-sm text-muted-foreground pt-1 border-t">
          <span>Talhão: {field?.name || '—'}</span>
          <button onClick={() => onDelete(crop)} className="inline-flex items-center gap-1 text-destructive hover:underline">
            <Trash2 className="w-3 h-3" /> Tirar
          </button>
        </div>
      </CardContent>
    </Card>
  );
}