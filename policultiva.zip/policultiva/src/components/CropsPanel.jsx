import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, Sprout, Trash2, CalendarDays, Ruler, MapPin, Leaf, AlertTriangle } from 'lucide-react';
import { humidityStatus, SOIL_LABELS } from '@/lib/irrigation';
import { analyzeCompanions, CROP_LABELS } from '@/lib/companions';

const STATUS_BADGE = {
  ideal: 'text-emerald-700 bg-emerald-100',
  baixa: 'text-amber-700 bg-amber-100',
  alta: 'text-blue-700 bg-blue-100',
};
const STATUS_LABEL = { ideal: 'Tudo certo', baixa: 'Seco', alta: 'Molhado demais' };

export default function CropsPanel({ crops, fields, onAddCrop, onDelete }) {
  const grouped = fields.map((f) => ({ field: f, list: crops.filter((c) => c.field_id === f.id) }));
  const orphan = crops.filter((c) => !fields.find((f) => f.id === c.field_id));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">Veja o que está plantado em cada talhão.</p>
        <Button size="lg" onClick={onAddCrop}><Plus className="w-5 h-5 mr-2" /> Plantar cultura</Button>
      </div>

      {crops.length === 0 ? (
        <Card><CardContent className="p-10 text-center text-muted-foreground">
          <Sprout className="w-12 h-12 mx-auto mb-3 opacity-40" />
          <p className="font-medium">Nenhuma cultura plantada ainda.</p>
          <p className="text-sm">Toque em “Plantar cultura” para começar.</p>
        </CardContent></Card>
      ) : (
        grouped.map(({ field, list }) => (
          <div key={field.id} className="space-y-3">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-primary" />
              <h2 className="font-semibold">{field.name}</h2>
              <span className="text-sm text-muted-foreground">· {SOIL_LABELS[field.soil_type]} · {field.region}</span>
            </div>
            {(() => {
              const { good, bad } = analyzeCompanions(list.map((c) => c.name));
              if (!good.length && !bad.length) return null;
              return (
                <div className="flex flex-wrap items-center gap-2 text-sm">
                  {good.map(([a, b], i) => (
                    <span key={`g${i}`} className="inline-flex items-center gap-1 bg-emerald-100 dark:bg-emerald-900/50 text-emerald-800 dark:text-emerald-200 rounded-full px-2.5 py-1">
                      <Leaf className="w-3.5 h-3.5" /> Consórcio: {CROP_LABELS[a]} + {CROP_LABELS[b]}
                    </span>
                  ))}
                  {bad.map(([a, b], i) => (
                    <span key={`b${i}`} className="inline-flex items-center gap-1 bg-amber-100 dark:bg-amber-900/40 text-amber-800 dark:text-amber-200 rounded-full px-2.5 py-1">
                      <AlertTriangle className="w-3.5 h-3.5" /> Evite: {CROP_LABELS[a]} + {CROP_LABELS[b]}
                    </span>
                  ))}
                </div>
              );
            })()}
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {list.map((c) => {
                const st = humidityStatus(c);
                return (
                  <Card key={c.id}>
                    <CardContent className="p-4 space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center">
                            <Sprout className="w-5 h-5 text-primary" />
                          </div>
                          <div>
                            <h3 className="font-bold leading-tight">{c.name}</h3>
                            <p className="text-sm text-muted-foreground">{c.variety || 'Sem variedade'}</p>
                          </div>
                        </div>
                        <Badge className={STATUS_BADGE[st]}>{STATUS_LABEL[st]}</Badge>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Ruler className="w-4 h-4" /> {c.planted_area_hectares} ha
                      </div>
                      {c.planted_date && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <CalendarDays className="w-4 h-4" />
                          {new Date(c.planted_date).toLocaleDateString('pt-BR')}
                          {c.expected_harvest_date ? ` → colheita ${new Date(c.expected_harvest_date).toLocaleDateString('pt-BR')}` : ''}
                        </div>
                      )}
                      <div className="flex justify-end border-t pt-2">
                        <button onClick={() => onDelete(c)} className="inline-flex items-center gap-1 text-sm text-destructive hover:underline">
                          <Trash2 className="w-4 h-4" /> Remover
                        </button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        ))
      )}
    </div>
  );
}