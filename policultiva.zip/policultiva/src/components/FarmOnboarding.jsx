import React, { useState } from 'react';
import { db } from '@/lib/db';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Leaf, User, MapPin, Sprout, Droplets } from 'lucide-react';
import { SOIL_LABELS } from '@/lib/irrigation';

const CLIMATE_LABELS = {
  tropical: 'Tropical (quente o ano todo)',
  semitropical: 'Semitropical',
  temperado: 'Temperado',
  seco: 'Seco / semiárido',
  umido: 'Úmido / chuvoso',
};

export default function FarmOnboarding({ onComplete }) {
  const [data, setData] = useState({
    farmer_name: '',
    farm_name: '',
    city: '',
    state: '',
    climate: 'tropical',
    soil_type: 'franco',
    water_source: '',
    area_hectares: '',
    experience_years: '',
    main_crops: '',
    land_registration_document: '',
  });
  const [saving, setSaving] = useState(false);

  const set = (k, v) => setData((d) => ({ ...d, [k]: v }));

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        ...data,
        area_hectares: Number(data.area_hectares) || 0,
        experience_years: data.experience_years ? Number(data.experience_years) : undefined,
      };
      const rec = await db.FarmProfile.create(payload);
      onComplete(rec);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 via-background to-muted/30 dark:from-emerald-950/40 dark:via-background dark:to-muted/20 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-600 to-green-500 text-white flex items-center justify-center mx-auto mb-4 shadow-soft ring-1 ring-emerald-200 dark:ring-emerald-800">
            <Leaf className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight">Bem-vindo à Policultiva</h1>
          <p className="text-muted-foreground mt-1">Primeiro, conte um pouco sobre você e sua terra. Assim podemos dar os melhores conselhos.</p>
        </div>

        <Card className="shadow-soft">
          <CardContent className="p-6">
            <form onSubmit={submit} className="space-y-5">
              <div className="flex items-center gap-2 text-emerald-700">
                <User className="w-5 h-5" />
                <h2 className="font-semibold">Sobre você</h2>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="farmer_name">Seu nome</Label>
                  <Input id="farmer_name" required value={data.farmer_name} onChange={(e) => set('farmer_name', e.target.value)} placeholder="Ex: João Silva" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="farm_name">Nome da fazenda/sítio</Label>
                  <Input id="farm_name" required value={data.farm_name} onChange={(e) => set('farm_name', e.target.value)} placeholder="Ex: Sítio Boa Vista" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="experience_years">Anos de experiência</Label>
                  <Input id="experience_years" type="number" min="0" value={data.experience_years} onChange={(e) => set('experience_years', e.target.value)} placeholder="Ex: 10" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="main_crops">O que costuma plantar</Label>
                  <Input id="main_crops" value={data.main_crops} onChange={(e) => set('main_crops', e.target.value)} placeholder="Ex: milho, feijão, mandioca" />
                </div>
              </div>

              <div className="flex items-center gap-2 text-emerald-700 pt-2">
                <MapPin className="w-5 h-5" />
                <h2 className="font-semibold">Onde fica sua terra</h2>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="city">Cidade</Label>
                  <Input id="city" required value={data.city} onChange={(e) => set('city', e.target.value)} placeholder="Ex: Patrocínio" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="state">Estado</Label>
                  <Input id="state" required value={data.state} onChange={(e) => set('state', e.target.value)} placeholder="Ex: Minas Gerais" />
                </div>
                <div className="space-y-1.5">
                  <Label>Clima da região</Label>
                  <Select value={data.climate} onValueChange={(v) => set('climate', v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(CLIMATE_LABELS).map(([k, v]) => (
                        <SelectItem key={k} value={k}>{v}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Tipo de solo</Label>
                  <Select value={data.soil_type} onValueChange={(v) => set('soil_type', v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(SOIL_LABELS).map(([k, v]) => (
                        <SelectItem key={k} value={k}>{v}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="land_registration_document">Documento de registro da terra</Label>
                <Input id="land_registration_document" value={data.land_registration_document} onChange={(e) => set('land_registration_document', e.target.value)} placeholder="Ex: Matrícula nº 1234 / CCIR" />
              </div>

              <div className="flex items-center gap-2 text-emerald-700 pt-2">
                <Sprout className="w-5 h-5" />
                <h2 className="font-semibold">Tamanho e água</h2>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="area_hectares">Área total (hectares)</Label>
                  <Input id="area_hectares" type="number" step="0.1" min="0" required value={data.area_hectares} onChange={(e) => set('area_hectares', e.target.value)} placeholder="Ex: 5" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="water_source"><Droplets className="w-4 h-4 inline mr-1" />De onde vem a água</Label>
                  <Input id="water_source" value={data.water_source} onChange={(e) => set('water_source', e.target.value)} placeholder="Ex: Poço, rio, represa" />
                </div>
              </div>

              <Button type="submit" size="lg" className="w-full text-base" disabled={saving}>
                {saving ? 'Salvando...' : 'Começar a usar'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}