import { useEffect } from 'react';
import { HashRouter as Router, Route, Routes } from 'react-router-dom';
import { FarmProvider, useFarm } from '@/lib/FarmContext';
import PageNotFound from '@/lib/PageNotFound';
import ScrollToTop from '@/components/ScrollToTop';
import FarmOnboarding from '@/components/FarmOnboarding';
import Home from '@/pages/Home';
import Settings from '@/pages/Settings';
import { OverviewSection, RecommendationsSection, IrrigationSection, DevicesSection, FinanceSection, CropsSection } from '@/components/policultiva/sections';

function ThemeSync() {
  useEffect(() => {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const apply = () => {
      const root = document.documentElement;
      if (root.classList.contains('light')) return;
      root.classList.toggle('dark', mq.matches);
    };
    apply();
    mq.addEventListener('change', apply);
    return () => mq.removeEventListener('change', apply);
  }, []);
  return null;
}

// Sem perfil de fazenda cadastrado → mostra o onboarding em qualquer rota.
function Gate() {
  const { loading, profile, completeOnboarding } = useFarm();
  if (loading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }
  if (!profile) return <FarmOnboarding onComplete={completeOnboarding} />;

  return (
    <Routes>
      <Route path="/" element={<Home />}>
        <Route index element={<OverviewSection />} />
        <Route path="recommendations" element={<RecommendationsSection />} />
        <Route path="irrigation" element={<IrrigationSection />} />
        <Route path="devices" element={<DevicesSection />} />
        <Route path="finance" element={<FinanceSection />} />
        <Route path="crops" element={<CropsSection />} />
      </Route>
      <Route path="/settings" element={<Settings />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
}

export default function App() {
  return (
    <Router>
      <ScrollToTop />
      <ThemeSync />
      <FarmProvider>
        <Gate />
      </FarmProvider>
    </Router>
  );
}
