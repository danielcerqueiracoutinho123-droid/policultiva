import React from 'react';
import { NavLink, Outlet, Link } from 'react-router-dom';
import { Leaf, LayoutDashboard, Droplets, Sprout, Wallet, Wifi, Sparkles, Settings as SettingsIcon } from 'lucide-react';
import { useFarm } from '@/lib/FarmContext';
import FieldDialog from '@/components/FieldDialog';
import CropDialog from '@/components/CropDialog';
import PullToRefresh from '@/components/PullToRefresh';

const TABS = [
  { to: '/', label: 'Visão geral', icon: LayoutDashboard, end: true },
  { to: '/recommendations', label: 'Recomendações', icon: Sparkles },
  { to: '/irrigation', label: 'Irrigação', icon: Droplets },
  { to: '/devices', label: 'Dispositivos', icon: Wifi },
  { to: '/finance', label: 'Financeiro', icon: Wallet },
  { to: '/crops', label: 'Culturas', icon: Sprout },
];

export default function Home() {
  const f = useFarm();
  const p = f.profile;

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="bg-gradient-to-r from-emerald-700 to-green-600 text-white shadow-soft select-none" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/20 ring-1 ring-white/30 flex items-center justify-center">
            <Leaf className="w-6 h-6" />
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="font-extrabold leading-tight truncate">{p.farm_name}</h1>
            <p className="text-sm text-emerald-50/90 truncate">{p.farmer_name} · {p.city} - {p.state}</p>
          </div>
          <Link to="/settings" aria-label="Configurações" className="w-11 h-11 rounded-2xl bg-white/20 flex items-center justify-center ring-1 ring-white/30 hover:bg-white/30 transition-colors">
            <SettingsIcon className="w-5 h-5" />
          </Link>
        </div>
        <nav className="max-w-6xl mx-auto px-2 flex gap-1 overflow-x-auto">
          {TABS.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium whitespace-nowrap rounded-t-lg transition-colors ${
                  isActive ? 'bg-background text-foreground' : 'text-emerald-50 hover:bg-white/10'
                }`}
            >
              <Icon className="w-4 h-4" /> {label}
            </NavLink>
          ))}
        </nav>
      </header>

      <PullToRefresh onRefresh={f.reload}>
        <main className="max-w-6xl mx-auto p-4 pb-[calc(3rem+env(safe-area-inset-bottom))]">
          <Outlet />
        </main>
      </PullToRefresh>

      <FieldDialog open={f.fieldOpen} onOpenChange={f.setFieldOpen} onSave={f.addField} />
      <CropDialog open={f.cropOpen} onOpenChange={f.setCropOpen} onSave={f.addCrop} fields={f.fields} />
    </div>
  );
}
