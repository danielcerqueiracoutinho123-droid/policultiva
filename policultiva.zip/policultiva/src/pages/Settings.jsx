import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { ArrowLeft, Trash2, AlertTriangle, Loader2, CheckCircle2, Leaf } from 'lucide-react';
import { SOIL_LABELS } from '@/lib/irrigation';
import { clearAllData } from '@/lib/db';
import { useFarm } from '@/lib/FarmContext';

const CLIMATE_LABELS = {
  tropical: 'Tropical (quente o ano todo)',
  semitropical: 'Semitropical',
  temperado: 'Temperado',
  seco: 'Seco / semiárido',
  umido: 'Úmido / chuvoso',
};

export default function Settings() {
  const { profile: farm } = useFarm();
  const [open, setOpen] = useState(false);
  const [confirmText, setConfirmText] = useState('');
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  const handleDelete = async () => {
    setDeleting(true);
    setError('');
    try {
      await clearAllData();
      setDeleting(false);
      setDone(true);
      setTimeout(() => { window.location.assign(window.location.pathname); }, 1500);
    } catch {
      setError('Não foi possível apagar agora. Tente novamente.');
      setDeleting(false);
    }
  };

  if (done) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-muted/30">
        <div className="text-center space-y-3 max-w-sm">
          <CheckCircle2 className="w-12 h-12 mx-auto text-emerald-600" />
          <h2 className="text-lg font-semibold">Dados apagados</h2>
          <p className="text-sm text-muted-foreground">Todos os dados foram apagados deste aparelho. Reiniciando…</p>
          <Loader2 className="w-5 h-5 mx-auto animate-spin text-muted-foreground" />
        </div>
      </div>
    );
  }

  const Row = ({ label, children, span }) => (
    <p className={span ? 'sm:col-span-2' : ''}><span className="text-muted-foreground">{label}: </span>{children || '—'}</p>
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50/70 via-background to-muted/30 dark:from-emerald-950/40 dark:via-background dark:to-muted/20">
      <header className="bg-gradient-to-r from-emerald-700 to-green-600 text-white shadow-soft sticky top-0 z-10 select-none" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center gap-3">
          <Link to="/" aria-label="Voltar" className="w-11 h-11 shrink-0 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center ring-1 ring-white/30 hover:bg-white/30 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div className="flex-1 min-w-0">
            <h1 className="text-xl font-extrabold leading-tight tracking-tight">Configurações</h1>
            <p className="text-sm text-emerald-50/90">Dados da fazenda e privacidade</p>
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6 pb-[calc(1.5rem+env(safe-area-inset-bottom))] space-y-6">
        <Card className="shadow-soft">
          <CardContent className="p-5 space-y-3">
            <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400">
              <Leaf className="w-5 h-5" />
              <h2 className="font-semibold">Dados da fazenda</h2>
            </div>
            {farm ? (
              <div className="space-y-2 text-sm">
                <p className="text-base font-semibold">{farm.farm_name || '—'}</p>
                <div className="grid sm:grid-cols-2 gap-x-4 gap-y-1.5">
                  <Row label="Proprietário">{farm.farmer_name}</Row>
                  <Row label="Documento da terra">{farm.land_registration_document}</Row>
                  <Row label="Cidade">{farm.city}</Row>
                  <Row label="Estado">{farm.state}</Row>
                  <Row label="Área">{farm.area_hectares != null ? `${farm.area_hectares} ha` : ''}</Row>
                  <Row label="Experiência">{farm.experience_years != null ? `${farm.experience_years} anos` : ''}</Row>
                  <Row label="Solo">{SOIL_LABELS[farm.soil_type] || farm.soil_type}</Row>
                  <Row label="Clima">{CLIMATE_LABELS[farm.climate] || farm.climate}</Row>
                  <Row label="Fonte de água">{farm.water_source}</Row>
                  <Row label="Culturas" span>{farm.main_crops}</Row>
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Nenhum perfil de fazenda cadastrado.</p>
            )}
          </CardContent>
        </Card>

        <Card className="border-destructive/30 shadow-soft">
          <CardContent className="p-5 space-y-4">
            <div className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="w-5 h-5" />
              <h2 className="font-semibold">Apagar dados</h2>
            </div>
            <p className="text-sm text-muted-foreground">
              Esta ação apaga permanentemente todos os dados do Policultiva neste aparelho — talhões, culturas, dispositivos, movimentações financeiras e perfil da fazenda. Não é possível desfazer.
            </p>
            <Button variant="destructive" onClick={() => { setConfirmText(''); setError(''); setOpen(true); }}>
              <Trash2 className="w-4 h-4 mr-2" /> Apagar meus dados
            </Button>
          </CardContent>
        </Card>
      </main>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirmar exclusão dos dados</DialogTitle>
            <p className="text-sm text-muted-foreground">
              Todos os talhões, culturas, dispositivos, transações e o perfil da fazenda serão apagados permanentemente. Digite <strong>APAGAR</strong> para confirmar.
            </p>
          </DialogHeader>
          <div className="space-y-2 py-2">
            <Label htmlFor="confirm">Confirmação</Label>
            <Input id="confirm" value={confirmText} onChange={(e) => setConfirmText(e.target.value)} placeholder="APAGAR" autoFocus />
            {error && <p className="text-sm text-destructive">{error}</p>}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} disabled={deleting}>Cancelar</Button>
            <Button variant="destructive" onClick={handleDelete} disabled={deleting || confirmText !== 'APAGAR'}>
              {deleting ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Apagando…</> : 'Apagar tudo'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
