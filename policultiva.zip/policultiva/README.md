# Policultiva

Gestão da fazenda: talhões, culturas, irrigação, dispositivos ESP32, finanças e recomendações de manejo.

```bash
npm install
npm run dev      # desenvolvimento
npm run build    # gera ./dist
npm run preview  # testa o build
```

- Os dados ficam no `localStorage` do navegador (`src/lib/db.js`).
- As recomendações usam a previsão do tempo da Open-Meteo (sem chave de API).
- Dispositivos ESP32: `GET /status` e `POST /relay` em HTTP na rede local.
